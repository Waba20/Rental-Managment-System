/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



public class Project {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
